<?php
namespace JKingWeb\DrUUID;

class UUIDException extends \Exception {
}