<?php
namespace JKingWeb\DrUUID;

class UUIDStorageException extends UUIDException {
}